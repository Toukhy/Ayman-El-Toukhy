using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using System;
//using UI_Automation.Utilities;

namespace Challenge
{
    [TestClass]
    public class LoginAction
    {
        private IWebDriver driver;
        private WebDriverWait wait;
        string email = "CHANGE HERE";
        string passWord = "CHANGE HERE";

        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        [TestInitialize()]
        // This attribute is needed when we want to run a function before execution of a test.
        public void SetupTest()
        {

            switch (TestContext.TestName)
            {
                case "Chrome":
                    driver = new ChromeDriver();
                    break;
                case "Firefox":
                    driver = new FirefoxDriver();
                    break;
                case "IE":
                    driver = new InternetExplorerDriver();
                    break;
                default:
                    ChromeOptions options = new ChromeOptions();
                    options.AddArguments("--disable-notifications");
                    driver = new ChromeDriver(options);

                    break;
            }

        }

        [TestCleanup()]
        // This attribute is needed when we want to execute a function after test execution finishes
        public void MyTestCleanup()
        {
            driver.Quit();
        }

        [TestMethod]
        public void Login()
        {
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));
            loginPage login = new loginPage(driver);

            driver.Manage().Window.Maximize();
            login.goToPage();
            login.login(email, passWord);
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div/div[2]/div/div/div[3]/div/div[2]/div/div/div/div[1]/div")));
            login.newPost("this is an automated post using selenium <3");
        }
    }
}