﻿using System;
using System.IO;
using System.Net;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;

namespace Challenge
{
    class loginPage
    {
        String url = "https://en-gb.facebook.com/";
        private IWebDriver driver;
        private WebDriverWait wait;



        public loginPage(IWebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            PageFactory.InitElements(driver, this);
        }




        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div[2]/div[1]/div/div/div/div[2]/div/div[1]/form/div[1]/div[1]/input")]
        private IWebElement emailField;

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div[2]/div[1]/div/div/div/div[2]/div/div[1]/form/div[1]/div[2]/div/input")]
        private IWebElement pwField;

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div[2]/div[1]/div/div/div/div[2]/div/div[1]/form/div[2]/button")]
        private IWebElement submitButton;


        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div/div[2]/div/div/div[3]/div/div[2]/div/div/div/div[1]/div")]
        private IWebElement postButton;

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[2]/div[1]/div[1]/div[1]" +
            "/div/div/div/div/div/div/div/div/div")]
        private IWebElement postText;

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[3]/div[2]/div")]
        private IWebElement postSubmit;

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[3]/div[1]/div[2]/div/div[1]/div/span/div/div/div[1]/div/div/div[1]")]
        private IWebElement addPhoto;

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div/div[1]/div")]
        private IWebElement photoLink;
        


        public void goToPage()
        {
            driver.Navigate().GoToUrl(url);
        }

        public loginPage login(string username, string password)
        {
            emailField.SendKeys(username);
            pwField.SendKeys(password);
            submitButton.Submit();
            return new loginPage(driver);
        }

        public void newPost(string Post)
        {

            postButton.Click();
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[1]/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[2]/div[1]/div[1]/div[1]" +
            "/div/div/div/div/div/div/div/div/div")));
            postText.SendKeys(Post);
            postSubmit.Submit();
        }



    }

}
